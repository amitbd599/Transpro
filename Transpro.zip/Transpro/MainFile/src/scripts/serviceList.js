let serviceList = [
  {
    title: "SEA TRANSPORTATION",
    des: "Intrinsicly exploit e-business imperative with emerging human capital.",
    img: "assets/img/service/1.png",
    icon: "assets/img/service/service-icon-1.png",
  },
  {
    title: "AIR TRANSPORTATION",
    des: "Intrinsicly exploit e-business imperative with emerging human capital.",
    img: "assets/img/service/2.png",
    icon: "assets/img/service/service-icon-2.png",
  },
  {
    title: "WAREHOUSING",
    des: "Intrinsicly exploit e-business imperative with emerging human capital.",
    img: "assets/img/service/3.png",
    icon: "assets/img/service/service-icon-3.png",
  },
  {
    title: "ROAD TRANSPORTATION",
    des: "Intrinsicly exploit e-business imperative with emerging human capital.",
    img: "assets/img/service/4.png",
    icon: "assets/img/service/service-icon-4.png",
  },
  {
    title: "TRAIN TRANSPORTATION",
    des: "Intrinsicly exploit e-business imperative with emerging human capital.",
    img: "assets/img/service/5.png",
    icon: "assets/img/service/service-icon-5.png",
  },
  {
    title: "LAND TRANSPORTATION",
    des: "Intrinsicly exploit e-business imperative with emerging human capital.",
    img: "assets/img/service/6.png",
    icon: "assets/img/service/service-icon-6.png",
  },
];

export default serviceList;
